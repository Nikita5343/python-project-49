### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nikita5343/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Nikita5343/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/e0426aa8fabac2c5fcc2/maintainability)](https://codeclimate.com/github/Nikita5343/python-project-49/maintainability)

brain-even:
https://asciinema.org/a/mvyV65BEYWpwkBVjT7hhbEn9l